from django.contrib import admin
from django.urls import path
from .views import CategoryCreateView , CategoryUpdateView ,CategoryDeleteView ,SubCategoryCreateView , SubCategoryUpdateView , SubCategoryDeleteView
urlpatterns = [
  
    path('',CategoryCreateView.as_view() , name='category-list'),
    path('category_update/<int:pk>',CategoryUpdateView.as_view() , name='category_update'),
    path('category_delete/<int:pk>',CategoryDeleteView.as_view() , name='category_delete'),


    path('subcategory-list/',SubCategoryCreateView.as_view() , name='subcategory-list'),
    path('subcategory-update/<int:pk>',SubCategoryUpdateView.as_view() , name='subcategory-update'),
    path('subcategory-delete/<int:pk>',SubCategoryDeleteView.as_view() , name='subcategory-delete'),





]
