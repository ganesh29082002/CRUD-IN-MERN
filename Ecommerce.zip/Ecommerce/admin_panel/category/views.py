from django.shortcuts import render, redirect, get_object_or_404
from django.http import HttpResponse
from django.views import View
from .models import Category , SubCategory
from .forms import CategoryForm, SubCategoryForm


# CRUD for Category
class CategoryCreateView(View):
    def get(self, request):
        form = CategoryForm()
        categories = Category.objects.all()
        return render(request, 'category_list.html', {'form': form, 'categories': categories})

    def post(self, request):
        form = CategoryForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('/') 
        categories = Category.objects.all()
        return render(request, 'category_list.html', {'form': form, 'categories': categories})

class CategoryUpdateView(View):
    def get(self, request, pk):
        category = get_object_or_404(Category, pk=pk)
        form = CategoryForm(instance=category)
        categories = Category.objects.all()
        return render(request, 'category_list.html', {'form': form , 'categories': categories})

    def post(self, request, pk):
        category = get_object_or_404(Category, pk=pk)
        form = CategoryForm(request.POST, instance=category)
        if form.is_valid():
            form.save()
            return redirect('/')
        return render(request, 'category_list.html', {'form': form})


class CategoryDeleteView(View):
    def get(self, request, pk):
        category = get_object_or_404(Category, pk=pk)
        return render(request, 'category_confirm_delete.html', {'category': category})

    def post(self, request, pk):
        category = get_object_or_404(Category, pk=pk)
        category.delete()
        return redirect('/')








class SubCategoryCreateView(View):
    def get(self, request):
        form = SubCategoryForm()
        subCategory = SubCategory.objects.all()
        return render(request, 'sub_category_list.html', {'form': form , 'subCategory': subCategory})

    def post(self, request):
        form = SubCategoryForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('subcategory-list')
        subCategory = SubCategory.objects.all()
        
        return render(request, 'sub_category_list.html', {'form': form , 'subCategory': subCategory})


class SubCategoryUpdateView(View):
    def get(self, request, pk):
        subcategory = get_object_or_404(SubCategory, pk=pk)
        form = SubCategoryForm(instance=subcategory)
        subcategory = SubCategory.objects.all()
        return render(request, 'sub_category_list.html', {'form': form , 'subCategory': subcategory})

    def post(self, request, pk):
        subcategory = get_object_or_404(SubCategory, pk=pk)
        form = SubCategoryForm(request.POST, instance=subcategory)
        if form.is_valid():
            form.save()
            return redirect('subcategory-list')
        return render(request, 'sub_category_list.html', {'form': form})


class SubCategoryDeleteView(View):
    def get(self, request, pk):
        subcategory = get_object_or_404(SubCategory, pk=pk)
        return render(request, 'subcategory_confirm_delete.html', {'subcategory': subcategory})

    def post(self, request, pk):
        subcategory = get_object_or_404(SubCategory, pk=pk)
        subcategory.delete()
        return redirect('subcategory-list')