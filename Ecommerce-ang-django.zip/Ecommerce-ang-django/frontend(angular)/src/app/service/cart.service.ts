import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CartService {

  constructor(private http: HttpClient) { }
 
   private API_BASE_URL = 'http://127.0.0.1:8000'; 

     //add to user 
  addToCart(product: any , token:any): Observable<any> {
    const url = `${this.API_BASE_URL}/api/user/cart/add-to-cart/`; 
    return this.http.post(url, { product_id: product.id , quantity: 1 },{
      headers: {
        Authorization: `Bearer ${token}`
      }
    });
  }

  fetchCarts(token:any): Observable<any> {

    const url = `${this.API_BASE_URL}/api/user/cart/cart-items`; 
    return this.http.get(url, {
      headers: {
        Authorization: `Bearer ${token}`
      }
    });
  }

  increaseQuantity(product: any , token:any): Observable<any> {
    console.log(product , "increaseQuantity")
    const url = `${this.API_BASE_URL}/api/user/cart/update-cart-item/`; 
    return this.http.post(url, { item_id: product.id , quantity: product.quantity+1 },{
      headers: {
        Authorization: `Bearer ${token}`
      }
    });
  }
  decreaseQuantity(product: any , token:any): Observable<any> {
    console.log(product , "decreaseQuantity")
    const url = `${this.API_BASE_URL}/api/user/cart/update-cart-item/`; 
    return this.http.post(url, { item_id: product.id , quantity: product.quantity-1 },{
      headers: {
        Authorization: `Bearer ${token}`
      }
    });
  }

  removeFromCart(product: any , token:any): Observable<any> {
    const url = `${this.API_BASE_URL}/api/user/cart/remove-cart-item/${product.id}/`; 
    return this.http.delete(url, {
      headers: {
        Authorization: `Bearer ${token}`
      }
    });
  }

  clearCartItems(token:any): Observable<any> {
    const url = `${this.API_BASE_URL}/api/user/cart/clear-cart/`; 
    return this.http.delete(url, {
      headers: {
        Authorization: `Bearer ${token}`
      }
    });
  }

}
