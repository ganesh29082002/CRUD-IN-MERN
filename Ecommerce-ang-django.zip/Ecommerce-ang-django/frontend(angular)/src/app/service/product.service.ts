import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { Observable, BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ProductService {


  private cartCountSubject: BehaviorSubject<number>;
  private apiUrl = 'http://127.0.0.1:8000/product/'; 

  constructor(private http: HttpClient) {
    console.log("product service")
    // const initialCartCount = 0;
    // this.cartCountSubject = new BehaviorSubject<number>(initialCartCount);
    const cartArray = JSON.parse(localStorage.getItem('cart') || '[]');

    // Initialize cart count from local storage
    const localCartCount = cartArray.length;
  const token = localStorage.getItem('access_token')
    // Create BehaviorSubject with a default value of 0
    this.cartCountSubject = new BehaviorSubject<number>(0);
  
    // Fetch the cart count from the API and update the BehaviorSubject
    this.http.get<{ total_count: number }>('http://127.0.0.1:8000/api/user/cart/get-total-count/',
      {
        headers: {
          Authorization: `Bearer ${token}`
        }
      }
    )
      .subscribe(response => {
        const apiCartCount = response.total_count || 0; // Default to 0 if count is missing
        const initialCartCount = apiCartCount + localCartCount;
        this.cartCountSubject.next(initialCartCount);
      });
  
  }

  // Get all products
  getProducts(): Observable<any[]> {
    return this.http.get<any[]>(this.apiUrl);
  }

  // Get a single product by ID
  getProductById(id: string): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}/${id}`);
  }

  // Create a new product
  createProduct(product: any): Observable<any> {
    return this.http.post<any>(this.apiUrl, product);
  }

  // Update an existing product
  updateProduct(id: string, product: any): Observable<any> {
    return this.http.put<any>(`${this.apiUrl}/${id}`, product);
  }

  // Delete a product
  deleteProduct(id: string): Observable<any> {
    return this.http.delete<any>(`${this.apiUrl}/${id}`);
  }


  getCartCount(): Observable<number> {
    return this.cartCountSubject.asObservable();
  }

  updateCartCount(count: number): void {
    this.cartCountSubject.next(count);
  }
}



