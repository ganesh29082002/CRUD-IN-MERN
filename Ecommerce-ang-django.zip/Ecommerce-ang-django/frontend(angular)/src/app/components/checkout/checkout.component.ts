import { Component , OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormArray, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-checkout',
  templateUrl: './checkout.component.html',
  styleUrl: './checkout.component.css'
})
export class CheckoutComponent implements OnInit {
  checkoutForm: FormGroup;
  selectedAddress: number = 0;


 

  constructor(private fb: FormBuilder , private router: Router) {
    this.checkoutForm = this.fb.group({
      addresses: this.fb.array([
        this.createAddressForm({
          street: '1234 Main St',
          city: 'Sample City',
          state: 'Sample State',
          zip: '12345',
        }),
      ]),
    });
  }

  // Create an address FormGroup
  createAddressForm(address = { street: '', city: '', state: '', zip: '' }): FormGroup {
    return this.fb.group({
      street: [address.street, Validators.required],
      city: [address.city, Validators.required],
      state: [address.state, Validators.required],
      zip: [address.zip, Validators.required],
    });
  }

  // Get addresses as FormArray
  get addresses(): FormArray {
    return this.checkoutForm.get('addresses') as FormArray;
  }

  // Handle radio button change
  onSelectAddress(index: number): void {
    this.selectedAddress = index;
  }

  // Add new address
  addAddress(): void {
    this.addresses.push(this.createAddressForm());
    this.selectedAddress = this.addresses.length - 1;
  }



  cart1: any;


  ngOnInit(): void {
    const navigation = this.router.getCurrentNavigation();
    console.log(navigation , "navigation")
    this.cart1 = navigation?.extras.state?.['cart'];
    console.log(this.cart1 , "cart")
    this.cart1 = history.state;
    console.log(this.cart1);
  }


}

