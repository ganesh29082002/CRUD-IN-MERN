import { Component } from '@angular/core';

@Component({
  selector: 'app-about',
  templateUrl: './about.component.html',
  styleUrl: './about.component.css'
})
export class AboutComponent {
  aboutMeta = "MORE ABOUT US"
  aboutDescription = "Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis,"
  aboutTitle = "This is about us page"
   
  serviceName = "Services"
  serviceDescription = "this is a service page velow are the services that we are providing"

  services = [
    {
      title: 'Digital Payment Solutions',
      description:
        'Revolutionizing payments with UPI, mobile wallets, and Bharat QR for a seamless and cashless experience.',
      icon: 'bi bi-phone',
      link: 'digital-payment-details.html',
    },
    {
      title: 'E-Governance Services',
      description:
        'Providing Aadhaar card updates, PAN card applications, and government scheme registrations under one roof.',
      icon: 'bi bi-person-badge',
      link: 'e-governance-details.html',
    },
    {
      title: 'Agriculture Consulting',
      description:
        'Helping farmers with crop selection, weather updates, and government subsidies to maximize yield.',
      icon: 'bi bi-flower2',
      link: 'agriculture-consulting-details.html',
    },
    {
      title: 'Educational Training',
      description:
        'Empowering students through online classes, skill development, and competitive exam preparation.',
      icon: 'bi bi-book',
      link: 'education-training-details.html',
    },
    {
      title: 'Healthcare Services',
      description:
        'Connecting patients with doctors, offering telemedicine, and ensuring affordable healthcare access.',
      icon: 'bi bi-heart-pulse',
      link: 'healthcare-details.html',
    },
    {
      title: 'Travel and Tourism',
      description:
        'Offering curated travel packages to popular Indian destinations like Goa, Kerala, and the Himalayas.',
      icon: 'bi bi-geo-alt',
      link: 'travel-tourism-details.html',
    },
    {
      title: 'E-Commerce Support',
      description:
        'Helping local businesses set up online stores and sell products through platforms like Flipkart and Amazon.',
      icon: 'bi bi-cart',
      link: 'ecommerce-support-details.html',
    },
    {
      title: 'Renewable Energy Solutions',
      description:
        'Promoting solar power, wind energy, and sustainable practices for a greener India.',
      icon: 'bi bi-sun',
      link: 'renewable-energy-details.html',
    },
  ];
  

}
