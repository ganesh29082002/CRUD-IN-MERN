import { Component } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrl: './home.component.css'
})
export class HomeComponent {
  companybadge = ' Working for your success';
  heading = 'Welcome to our ecoomerce website!';
  subheading = 'We offer a wide range of products at affordable prices.';
  details = 'We are delighted to have you here. Explore our products and services.';
  imageUrl = 'path-to-image.jpg';

}
