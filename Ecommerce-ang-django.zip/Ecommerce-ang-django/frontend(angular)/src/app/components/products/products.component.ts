import { Component, OnInit } from '@angular/core';
import { ProductService } from '../../service/product.service';
import { CartService } from '../../service/cart.service';
import Swal from 'sweetalert2';
import { Router } from '@angular/router';
import { authGuard } from '../../guards/auth.guard';
@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {
  products: any[] = [];
  cart: any[] = [];

  cartCount: number = 0;

  constructor(private productService: ProductService , private cartService: CartService, private router: Router) {}

  ngOnInit(): void {
    this.loadProducts();
    this.loadCart();
  }

  
  loadProducts(): void {
    this.productService.getProducts().subscribe({
      next: (data) => (this.products = data),
      error: (err) => console.error(err),
    });
  }

  
  // addToCart(product: any): void {

  //   const token = localStorage.getItem('access_token'); // Check if user is logged in

  //   if (!token) {
  //     // If not logged in, show alert
  //     alert('Please log in to add items to the cart!');
  //     this.router.navigate(['/login']); // Optionally, navigate to login page
  //     return; // Prevent adding to cart if not logged in
  //   }
  //   const cart = JSON.parse(localStorage.getItem('cart') || '[]');

    
  //   const existingProduct = cart.find((item: any) => item.id === product.id);

  //   if (existingProduct) {
    
  //     existingProduct.quantity += 1;
     

  //   } else {

  //     cart.push({ ...product, quantity: 1 });

  //     this.productService.getCartCount().subscribe(count => {
  //       console.log("count ",count)
  //       this.cartCount = count;
  //     });
     
    
  //     this.productService.updateCartCount(this.cartCount +1 );
  //   }


  //   localStorage.setItem('cart', JSON.stringify(cart));

  //   this.loadCart();

  //   this.showAlert(product.name)

  //   // alert(`${product.name} has been added to the cart!`);
  // }


  addToCart(product: any): void {

    const token = localStorage.getItem('access_token'); // Check if user is logged in

    if (!token) {
      // If not logged in, show alert
      alert('Please log in to add items to the cart!');
      this.router.navigate(['/login']); // Optionally, navigate to login page
      return; // Prevent adding to cart if not logged in
    }
    

    this.cartService.addToCart(product , token).subscribe({
      next: (data) => {
        this.showAlert(data.name);
        this.productService.getCartCount().subscribe(count => {
                console.log("count ",count)
                this.cartCount = count;
              });
             
            
              this.productService.updateCartCount(data.total_count);
        this.loadCart();
      },
      error: (err) => console.error(err),
    });
    // alert(`${product.name} has been added to the cart!`);
  }

  
  loadCart(): void {
    this.cart = JSON.parse(localStorage.getItem('cart') || '[]');
  }



  showAlert(message: string): void {
    Swal.fire({
      title: 'Success!',
      text: ` ${message} has been added to the cart!`,
      icon: 'success',
      confirmButtonText: 'OK'
    });
  }
}
