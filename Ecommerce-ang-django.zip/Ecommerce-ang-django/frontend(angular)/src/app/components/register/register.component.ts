import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AuthService } from '../../service/auth.service';
import { Router } from '@angular/router'; 
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  registerForm!: FormGroup;
  submitted = false;
  serverError: string | null = null;

  constructor(private formBuilder: FormBuilder,
    private router: Router, private authService: AuthService) { }

  ngOnInit(): void {
    this.registerForm = this.formBuilder.group({
      email: ['', [Validators.required, Validators.email]],
      username: ['', [Validators.required]],
      first_name: ['', Validators.required],
      last_name: ['', Validators.required],
      address: ['', Validators.required],
      postal_code: ['', [Validators.required, Validators.pattern('^[0-9]{6}$')]], // Validate 6-digit postal code
      contact_number: ['', [Validators.required, Validators.pattern('^[0-9]{10}$')]], // Validate 10-digit phone number
      password: ['', [Validators.required, Validators.minLength(6)]],
    });
  }

  // Getter for form controls
  get f() {
    return this.registerForm.controls;
  }

  onSubmit() {
    this.submitted = true;

    // Stop submission if the form is invalid
    if (this.registerForm.invalid) {
      console.log(this.registerForm.invalid)
      return;
    }

    this.serverError = null; // Reset any server error
    console.log(this.registerForm.value , "this.registerForm.value")
    // Call the register service
    this.authService.register(this.registerForm.value).subscribe({
      next: (response) => {
        console.log('User registered successfully', response);
        alert('Registration Successful!');

        this.resetForm();
        this.router.navigate(['/login']); 
      },
      error: (error) => this.handleServerError(error),
    });
  }

  // Handle server errors
  private handleServerError(error: any) {
    if (error.status === 400) {
      this.serverError = 'Invalid data submitted. Please check your inputs.';
    } else if (error.status === 409) {
      this.serverError = 'User already exists with this email.';
    } else {
      this.serverError = 'Something went wrong. Please try again later.';
    }
    console.error('Registration error', error);
  }

  // Reset the form
  private resetForm(): void {
    this.registerForm.reset();
    this.submitted = false;

    // Reset validation state
    Object.keys(this.registerForm.controls).forEach((key) => {
      this.registerForm.controls[key].setErrors(null);
    });
  }
}
