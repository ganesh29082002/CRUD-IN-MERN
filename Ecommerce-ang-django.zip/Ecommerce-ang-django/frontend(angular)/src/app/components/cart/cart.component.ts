import { Component, OnInit } from '@angular/core';
import { ProductService } from '../../service/product.service';
import { CartService } from '../../service/cart.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {
  cart: any[] = [];
  totalPrice: number = 0;

  constructor(private productService : ProductService , private cartService : CartService ,private router: Router) {}
  
  couponCode:string = ""
   token = localStorage.getItem('access_token');

  applyCoupon(): void {
    if (this.couponCode === "FIRST_COUPON") {
      this.totalPrice *= 0.9;
    }else{
      alert("Coupon code not valid!");
    }
  }

  ngOnInit(): void {
    this.loadCart();
  }

  // Load cart from localStorage
  loadCart(): void {
    this.cart = JSON.parse(localStorage.getItem('cart') || '[]');
  
    // Convert localStorage cart values to numbers
    this.cart = this.cart.map((item: any) => ({
      ...item,
      price_price: parseFloat(item.price_price),
      price_quantity: parseInt(item.price_quantity, 10),
    }));
  
    this.cartService.fetchCarts(this.token).subscribe({
      next: (data: any[]) => {
        console.log(data, "Cart data from backend");
  
        // Merge and convert backend data
        const backendCart = data.map((item) => ({
          ...item,
          price_price: parseFloat(item.price_price),
          price_quantity: parseInt(item.price_quantity, 10),
        }));
  
        this.cart.push(...backendCart);
        this.calculateTotalPrice();
      },
      error: (err) => console.error(err),
    });
  }

  // Calculate the total price of the cart
  calculateTotalPrice(): void {
    console.log(this.cart , "calculateTotalPrice")
    this.totalPrice = this.cart.reduce((sum, product) => sum + Number(product.product_price) * Number(product.quantity), 0);
  }

  // Increase quantity of a product
  increaseQuantity(product: any): void {
    if(!this.token){
      
    const cart = JSON.parse(localStorage.getItem('cart') || '[]');
    const existingProduct = cart.find((item: any) => item.id === product.id);

    if (existingProduct) {
      existingProduct.quantity += 1;
    }

    localStorage.setItem('cart', JSON.stringify(cart));
    this.loadCart();
  }else{
    this.cartService.increaseQuantity(product , this.token).subscribe({
      next: (data:any) => {
        this.loadCart();
      },
      error: (err:any) => console.error(err),
    })
  }

}


  // Decrease quantity of a product
  decreaseQuantity(product: any): void {
    console.log(product , "decreaseQuantity")
    if(!this.token){
    const cart = JSON.parse(localStorage.getItem('cart') || '[]');
    const existingProduct = cart.find((item: any) => item.id === product.id);

    if (existingProduct) {
      existingProduct.quantity -= 1;


      if (existingProduct.quantity === 0) {
        const index = cart.indexOf(existingProduct);
        cart.splice(index, 1);

        this.productService.updateCartCount(0);
      }

    }

    localStorage.setItem('cart', JSON.stringify(cart));
    this.loadCart();
  } else{
    this.cartService.decreaseQuantity(product , this.token).subscribe({
      next: (data:any) => {
        this.loadCart();
      },
      error: (err:any) => console.error(err),
    })
  }

}

  // Remove a product from the cart
  removeFromCart(product: any): void {
    if(!this.token){
    const cart = JSON.parse(localStorage.getItem('cart') || '[]');
    const updatedCart = cart.filter((item: any) => item.id !== product.id);

    localStorage.setItem('cart', JSON.stringify(updatedCart));
    this.loadCart();

    const initialCartCount = updatedCart.length;
    this.productService.updateCartCount(initialCartCount);

    alert(`${product.product_name} has been removed from the cart!`); 

    }else {
      this.cartService.removeFromCart(product , this.token).subscribe({
        next: (data:any) => {
          alert(`${product.product_name} has been removed from the cart!`);
          this.loadCart();
        },
        error: (err:any) => console.error(err),
      });
    }
  }


  

  checkOutCart(cart: any): void {
    console.log(cart , "checkOutCart")
    this.router.navigate(['/checkout'], { state:  cart  });
  }

  clearCart(){
    localStorage.removeItem('cart');
    this.cart = [];
    this.totalPrice = 0;
    this.cartService.clearCartItems(this.token).subscribe({
      next: (data:any) => {
        this.loadCart();
      },
      error: (err:any) => console.error(err),
    })
    alert("Cart has been cleared!");
  }
}
