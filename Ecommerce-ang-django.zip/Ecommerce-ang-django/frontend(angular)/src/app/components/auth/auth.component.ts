import { Component } from '@angular/core';
import { AuthService } from '../../service/auth.service';

@Component({
  selector: 'app-auth',
  templateUrl: './auth.component.html',
  styleUrl: './auth.component.css'
})
export class AuthComponent {

  constructor(private authService: AuthService) {}

  registerUser() {
    const userData = {
      email: 'user@example.com',
      password: 'password123',
      first_name: 'John',
      last_name: 'Doe',
      address: '123 Street',
      postal_code: '123456',
      contact_number: '9876543210',
    };

    this.authService.register(userData).subscribe({
      next: (response) => console.log('User registered successfully', response),
      error: (error) => console.error('Registration error', error),
    });
  }

  loginUser() {
    const loginData = {
      email: 'user@example.com',
      password: 'password123',
    };

    this.authService.login(loginData).subscribe({
      next: (response) => {
        console.log('Login successful', response);
        this.authService.saveTokens(response);
      },
      error: (error) => console.error('Login error', error),
    });
  }

}
