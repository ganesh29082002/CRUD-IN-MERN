
import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AuthService } from '../../service/auth.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {
  // constructor(private authService: AuthService) {}
  // loginUser() {
  //   const loginData = {
  //     email: 'user@example.com',
  //     password: 'password123',
  //   };

  //   this.authService.login(loginData).subscribe({
  //     next: (response) => {
  //       console.log('Login successful', response);
  //       this.authService.saveTokens(response);
  //     },
  //     error: (error) => console.error('Login error', error),
  //   });
  // }

  loginForm: FormGroup;
  submitted = false;
  serverError: string | null = null;

  constructor(private formBuilder: FormBuilder , 
    private router: Router, private authService: AuthService) {
    // Initialize the form group
    this.loginForm = this.formBuilder.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6)]],
    });
  }

  // Convenience getter for easy access to form fields
  get f() {
    return this.loginForm.controls;
  }

  onSubmit(): void {
    this.submitted = true;

    // Stop if the form is invalid
    if (this.loginForm.invalid) {
      return;
    }

    this.serverError = null; // Reset any server error
    this.authService.login(this.loginForm.value).subscribe({
      next: (response) => {
        console.log('User Login successfully', response);
        const refresh_token = response.refresh; 
        const access_token = response.access; 

        if (access_token) {
          localStorage.setItem('refresh_token', refresh_token);
          localStorage.setItem('access_token', access_token); 
        }

        alert('Login Successful!');

        this.resetForm();
        this.router.navigate(['/products']); 
      },
      error: (error) => this.handleServerError(error),
    });

    // Process the form (e.g., send to backend)
    console.log('Login data', this.loginForm.value);
    alert('Login successful!');
  }

   // Handle server errors
   private handleServerError(error: any) {
    if (error.status === 400) {
      this.serverError = 'Invalid data submitted. Please check your inputs.';
    } else if (error.status === 409) {
      this.serverError = 'User already exists with this email.';
    } else {
      this.serverError = 'Something went wrong. Please try again later.';
    }
    console.error('Registration error', error);
  }

  // Reset the form
  private resetForm(): void {
    this.loginForm.reset();
    this.submitted = false;

    // Reset validation state
    Object.keys(this.loginForm.controls).forEach((key) => {
      this.loginForm.controls[key].setErrors(null);
    });
  }

}
