import { Component } from '@angular/core';


@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrl: './contact.component.css'
})
export class ContactComponent {
 heading: string = "Contact"
 contact:any = {
  name:   "",
  subject: "",
  message: "",
 }


 visible = false;
  dismissible = true;
  alertMessage = "you have submit your form successfully " ;
  messageType : string = ""

 onSubmit(){
  console.log(this.contact)
   console.log(this.contact.name , this.contact.subject , this.contact.message)
   if(this.contact.name === "" || this.contact.subject === "" || this.contact.message ===""){
    this.alertMessage = "Please enter all fields"
    this.messageType = "danger"
   }else{
    this.alertMessage = "you have submit your form successfully "
    this.messageType = "success"
    this.contact = {
      name:   "",
      subject: "",
      message: "",
    }
    this.dismissible = false;
   }
   this.visible = true;
 }
 onAlertCLose(){
   this.visible = false;
 }


}


