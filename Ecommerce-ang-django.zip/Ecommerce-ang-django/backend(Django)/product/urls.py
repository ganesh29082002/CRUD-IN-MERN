from django.urls import path
from .views import ProductListView, ProductDetailView, ProductCreateView
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('', ProductListView.as_view(), name='product-list'),
    path('<int:pk>/', ProductDetailView.as_view(), name='product-detail'),
    path('create/', ProductCreateView.as_view(), name='product-create'),
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
