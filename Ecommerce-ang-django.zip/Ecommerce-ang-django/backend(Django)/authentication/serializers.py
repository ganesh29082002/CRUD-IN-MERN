from rest_framework import serializers
from django.contrib.auth import authenticate
from .models import CustomUser

class RegisterSerializer(serializers.ModelSerializer):
    password = serializers.CharField(write_only=True)

    class Meta:
        model = CustomUser
        fields = ['id', 'username', 'password', 'first_name' , 'last_name', 'email', 'address', 'postal_code', 'contact_number', 'is_admin', 'is_user']

    def create(self, validated_data):
        user = CustomUser.objects.create_user(
            email=validated_data['email'],
            username=validated_data['username'],
            password=validated_data['password'],
            address=validated_data['address'],
            first_name=validated_data['first_name'],
            last_name=validated_data['last_name'],
            postal_code=validated_data['postal_code'],
            contact_number=validated_data['contact_number'],
            is_admin=validated_data.get('is_admin', False),
            is_user=validated_data.get('is_user', True),
        )
        return user

class LoginSerializer(serializers.Serializer):
    email = serializers.EmailField()
    password = serializers.CharField(write_only=True)

    def validate(self, attrs):
        user = authenticate(email=attrs['email'], password=attrs['password'])
        if not user:
            raise serializers.ValidationError('Invalid email or password')
        return {'user': user}
