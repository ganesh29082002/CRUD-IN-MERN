from django.urls import path
from .views import RegisterView, LoginView, AdminView, UserView

urlpatterns = [
    path('register/', RegisterView.as_view(), name='register'),
    path('login/', LoginView.as_view(), name='login'),
    path('admin-view/', AdminView.as_view(), name='admin-view'),
    path('user-view/', UserView.as_view(), name='user-view'),
]