
# Register your models here.
from django.contrib import admin
from .models import DiscountCoupon, CouponUsage

@admin.register(DiscountCoupon)
class DiscountCouponAdmin(admin.ModelAdmin):
    list_display = ("code", "discount_percentage", "valid_until", "is_active")
    search_fields = ("code",)
    list_filter = ("is_active", "valid_until")

@admin.register(CouponUsage)
class CouponUsageAdmin(admin.ModelAdmin):
    list_display = ("user", "coupon", "used_at")
    search_fields = ("user__email", "coupon__code")
