from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from .serializers import CartItemSerializer
from rest_framework.permissions import IsAuthenticated
from .models import DiscountCoupon, CouponUsage
from .serializers import ApplyCouponSerializer, DiscountCouponSerializer
from django.utils.timezone import now
from django.core.mail import send_mail
from .models import Order, OrderItem
from .serializers import OrderSerializer
from .models import Cart, CartItem
from product.models import Product




# card related view 
class AddToCartView(APIView):
    # permission_classes = [IsAuthenticated]

    def post(self, request):
        product_id = request.data.get("product_id")
        quantity = request.data.get("quantity", 1)

        try:
            product = Product.objects.get(id=product_id)
        except Product.DoesNotExist:
            return Response({"error": "Product does not exist."}, status=status.HTTP_404_NOT_FOUND)

        cart, created = Cart.objects.get_or_create(user=request.user)

        # Check if the product is already in the cart
        cart_item, created = CartItem.objects.get_or_create(cart=cart, product=product)
        if not created:
            cart_item.quantity += quantity
        else:
            cart_item.quantity = quantity

        cart_item.save()
        total_count = cart.items.all().count()

        return Response({"message": "Product added to cart successfully." , "total_count":total_count}, status=status.HTTP_200_OK)

class TotalCartItemsView(APIView):
    # permission_classes = [IsAuthenticated]

    def get(self, request):
        try:
           
            cart = Cart.objects.get(user=request.user)

            total_count = cart.items.all().count()


            return Response({"total_count": total_count}, status=status.HTTP_200_OK)
        except Cart.DoesNotExist:
           
            return Response({"total_count": 0}, status=status.HTTP_200_OK)



class ListCartItemsView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        # Get or create the user's cart
        cart, _ = Cart.objects.get_or_create(user=request.user)
        
        # Get all items in the cart
        cart_items = CartItem.objects.filter(cart=cart)
        
        # Serialize the cart items
        serializer = CartItemSerializer(cart_items, many=True)
        
        return Response(serializer.data, status=200)

class UpdateCartItemQuantityView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request):
        item_id = request.data.get("item_id")
        quantity = request.data.get("quantity")

        try:
            cart_item = CartItem.objects.get(id=item_id, cart__user=request.user)
        except CartItem.DoesNotExist:
            return Response({"error": "Cart item does not exist."}, status=status.HTTP_404_NOT_FOUND)

        if quantity <= 0:
            cart_item.delete()
            return Response({"message": "Item removed from cart."}, status=status.HTTP_200_OK)

        cart_item.quantity = quantity
        cart_item.save()
        return Response({"message": "Cart item quantity updated successfully."}, status=status.HTTP_200_OK)


class RemoveCartItemView(APIView):
    permission_classes = [IsAuthenticated]

    def delete(self, request, item_id):
        try:
            cart_item = CartItem.objects.get(id=item_id, cart__user=request.user)
            cart_item.delete()
            return Response({"message": "Cart item removed successfully."}, status=status.HTTP_200_OK)
        except CartItem.DoesNotExist:
            return Response({"error": "Cart item does not exist."}, status=status.HTTP_404_NOT_FOUND)



# order related view 
class PlaceOrderView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request):
        user = request.user
        order_data = request.data
        items_data = order_data.pop('items', [])
        total_amount = sum(item['price'] * item['quantity'] for item in items_data)

        # Create the Order
        order = Order.objects.create(user=user, total_amount=total_amount)

        # Create Order Items
        for item in items_data:
            OrderItem.objects.create(order=order, **item)

        # Send email notification
        # send_mail(
        #     'Order Confirmation',
        #     f"Your order has been placed successfully! Total Amount: ${total_amount}, Expected Delivery Date: {order.expected_delivery_date.date()}",
        #     'noreply@yourshop.com',
        #     [user.email],
        #     fail_silently=False,
        # )

        return Response({"message": "Order placed successfully!", "order_id": order.id}, status=status.HTTP_201_CREATED)
    def get(self, request):
        user = request.user
        orders = Order.objects.filter(user=user).order_by('-order_date')
        serializer = OrderSerializer(orders, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)

    
class ApplyCouponView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request):
        serializer = ApplyCouponSerializer(data=request.data)
        if serializer.is_valid():
            code = serializer.validated_data.get("coupon_code")
            user = request.user

            # Validate coupon existence
            try:
                coupon = DiscountCoupon.objects.get(code=code, is_active=True)
            except DiscountCoupon.DoesNotExist:
                return Response({"error": "Invalid or inactive coupon."}, status=status.HTTP_400_BAD_REQUEST)

           
            if coupon.valid_until < now():
                return Response({"error": "This coupon has expired."}, status=status.HTTP_400_BAD_REQUEST)

            
            if CouponUsage.objects.filter(user=user, coupon=coupon).exists():
                return Response({"error": "You have already used this coupon."}, status=status.HTTP_400_BAD_REQUEST)

            
            discount_percentage = coupon.discount_percentage

            
            CouponUsage.objects.create(user=user, coupon=coupon)

            return Response({
                "message": "Coupon applied successfully!",
                "discount_percentage": discount_percentage
            }, status=status.HTTP_200_OK)

        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
