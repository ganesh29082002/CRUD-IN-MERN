from django.urls import path
from .views import  ApplyCouponView, PlaceOrderView
from .views import AddToCartView, TotalCartItemsView , ListCartItemsView, UpdateCartItemQuantityView, RemoveCartItemView

urlpatterns = [
    path('cart/add-to-cart/', AddToCartView.as_view(), name='add-to-cart'),
    path('cart/cart-items/', ListCartItemsView.as_view(), name='list-cart-items'),
    path('cart/update-cart-item/', UpdateCartItemQuantityView.as_view(), name='update-cart-item'),
    path('cart/remove-cart-item/<int:item_id>/', RemoveCartItemView.as_view(), name='remove-cart-item'),
    path('cart/apply-coupon/', ApplyCouponView.as_view(), name='apply-coupon'),
    path('cart/place-order/', PlaceOrderView.as_view(), name='apply-coupon'),
    path('cart/get-total-count/', TotalCartItemsView.as_view(), name='apply-coupon'),


    
]